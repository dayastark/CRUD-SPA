﻿
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace Schedule
{
    public class ExceptionHandlingMiddleware : IMiddleware
    {
        private readonly ILogger<ExceptionHandlingMiddleware> logger;

        public ExceptionHandlingMiddleware(ILogger<ExceptionHandlingMiddleware> logger)
        {
            this.logger = logger;
        }

        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            try
            {
                await next(context);
            }
            catch (Exception ex)
            {
                var message = $"Message: {Environment.NewLine + ex.Message} {Environment.NewLine}Trace: {Environment.NewLine + ex.StackTrace ?? String.Empty}";

                await context.Response.WriteAsync(message);
                logger.Log(LogLevel.Error, message);
            }
        }
    }
}
