﻿using Microsoft.AspNetCore.Components.Web;
using Schedule.Models;
using Schedule.Services;
using Syncfusion.Blazor.Buttons;
using Syncfusion.Blazor.Data;
using Syncfusion.Blazor.DropDowns;
using Syncfusion.Blazor.Inputs;
using Syncfusion.Blazor.Navigations;
using Syncfusion.Blazor.Schedule;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Timers;


namespace Schedule.Components.Pages
{
    public partial class Home
    {
        SfTextBox SubjectRef;
        SfCheckBox<bool> ViewRef;
        SfTextBox DescriptionRef;
        SfMultiSelect<int[], CalendarData> ResourceRef;
        SfSchedule<AppointmentData> ScheduleRef;
        SfDropDownList<int, CalendarData> CalendarRef;

        List<AppointmentData> DataSource = new AppointmentData().GetEvents();
        public AppointmentData EventData { get; set; }
        public CellClickEventArgs CellData { get; set; }
        private bool isCell { get; set; }
        private bool isEvent { get; set; }
        private bool isRecurrence { get; set; }
        private int SlotCount { get; set; } = 2;
        private int SlotInterval { get; set; } = 60;
        private int FirstDayOfWeek { get; set; } = 0;
        private bool EnableGroup { get; set; } = true;
        private bool TooltipEnable { get; set; } = false;
        private bool isRowAutoHeight { get; set; } = false;
        private bool EnableTimeScale { get; set; } = true;
        private bool ShowWeekNumber { get; set; } = false;
        private bool isQuickInfoCreated { get; set; } = false;
        private CalendarWeekRule WeekRule { get; set; } = CalendarWeekRule.FirstDay;
        private string WeeklyRule { get; set; } = "Off";
        private string Tooltipvalue { get; set; } = "Off";
        private View CurrentView { get; set; } = View.Week;
        private string SelectedView { get; set; } = "Week";
        private string DayStartHour { get; set; } = "00:00";
        private string DayEndHour { get; set; } = "24:00";
        private string WorkStartHour { get; set; } = "09:00";
        private string WorkEndHour { get; set; } = "18:00";
        private string TimeFormat { get; set; } = "hh:mm tt";
        private bool IsSettingsVisible { get; set; } = false;
        public string[] GroupData = new string[] { "Calendars" };
        private DateTime SystemTime { get; set; } = DateTime.UtcNow;
        private DateTime SelectedDate { get; set; } = DateTime.UtcNow;
        private DateTime? StartWorkHour { get; set; } = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 0, 0);
        private DateTime? EndWorkHour { get; set; } = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 18, 0, 0);
        private DateTime? ScheduleStartHour { get; set; } = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);
        private DateTime? ScheduleEndHour { get; set; } = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 59, 59);
        private int[] SelectedResource { get; set; } = new int[] { 1 };
        private int[] WorkDays { get; set; } = new int[] { 1, 2, 3, 4, 5 };
        private Timezone TimezoneData { get; set; } = new Timezone() { Name = "UTC+00:00", Key = "UTC", Value = "UTC" };
        private Query ResourceQuery { get; set; } = new Query().Where(new WhereFilter() { Field = "CalendarId", Operator = "equal", value = 1 });
        public List<CalendarData> Calendars { get; set; }

        public List<SlotData> SlotIntervalDataSource { get; set; }

        private List<SlotData> SlotCountDataSource { get; set; }
        private List<TimeFormatData> TimeFormatDataSource { get; set; }

        private List<WeekNumbers> WeekNumbersData { get; set; }

        private List<Tooltip> TooltipData { get; set; }

        private List<string> ScheduleViews { get; set; }
        private List<WeekDays> WeekCollection { get; set; }

        private List<Timezone> TimezoneCollection { get; set; }

        private Dictionary<string, object> htmlAttribute = new Dictionary<string, object>() { {"tabindex", "-1" } };

        private void OnViewChange(Syncfusion.Blazor.Buttons.ChangeEventArgs<bool> args)
        {
            switch (this.CurrentView)
            {
                case View.Day:
                case View.TimelineDay:
                    this.CurrentView = args.Checked ? View.TimelineDay : View.Day;
                    break;
                case View.Week:
                case View.TimelineWeek:
                    this.CurrentView = args.Checked ? View.TimelineWeek : View.Week;
                    break;
                case View.WorkWeek:
                case View.TimelineWorkWeek:
                    this.CurrentView = args.Checked ? View.TimelineWorkWeek : View.WorkWeek;
                    break;
                case View.Month:
                case View.TimelineMonth:
                    this.CurrentView = args.Checked ? View.TimelineMonth : View.Month;
                    break;
                case View.Year:
                case View.TimelineYear:
                    this.CurrentView = args.Checked ? View.TimelineYear : View.Year;
                    break;
                case View.Agenda:
                    this.CurrentView = View.Agenda;
                    break;
            }
        }
        private async void OnNewEventAdd()
        {
            DateTime Date = this.ScheduleRef.SelectedDate;
            DateTime Start = new DateTime(Date.Year, Date.Month, Date.Day, DateTime.Now.Hour, 0, 0);
            AppointmentData eventData = new AppointmentData
            {
                Id = await ScheduleRef.GetMaxEventIdAsync<int>(),
                Subject = "Add title",
                StartTime = Start,
                EndTime = Start.AddHours(1),
                Location = "",
                Description = "",
                IsAllDay = false,
                CalendarId = this.ResourceRef.Value[0]
            };
            await ScheduleRef.OpenEditorAsync(eventData, CurrentAction.Add);
        }

        private async void OnNewRecurringEventAdd()
        {
            DateTime Date = this.ScheduleRef.SelectedDate;
            DateTime Start = new DateTime(Date.Year, Date.Month, Date.Day, DateTime.Now.Hour, 0, 0);
            AppointmentData eventData = new AppointmentData
            {
                Id = await ScheduleRef.GetMaxEventIdAsync<int>(),
                Subject = "Add title",
                StartTime = Start,
                EndTime = Start.AddHours(1),
                Location = "",
                Description = "",
                IsAllDay = false,
                CalendarId = this.ResourceRef.Value[0],
                RecurrenceRule = "FREQ=DAILY;INTERVAL=1;"
            };
            await ScheduleRef.OpenEditorAsync(eventData, CurrentAction.Add);
        }
        private void OnDayView()
        {
            this.CurrentView = this.ViewRef.Checked ? View.TimelineDay : View.Day;
        }
        private void OnWeekView()
        {
            this.CurrentView = this.ViewRef.Checked ? View.TimelineWeek : View.Week;
        }
        private void OnWorkWeekView()
        {
            this.CurrentView = this.ViewRef.Checked ? View.TimelineWorkWeek : View.WorkWeek;
        }
        private void OnMonthView()
        {
            this.CurrentView = this.ViewRef.Checked ? View.TimelineMonth : View.Month;
        }
        private void OnYearView()
        {
            this.CurrentView = this.ViewRef.Checked ? View.TimelineYear : View.Year;
        }
        private void OnAgendaView()
        {
            this.CurrentView = View.Agenda;
        }
        private async void OnSettingsClick()
        {
            this.IsSettingsVisible = !this.IsSettingsVisible;
            StateHasChanged();
            await this.ScheduleRef.RefreshEventsAsync();
        }
        private string GetEventDetails(AppointmentData data)
        {
            return data.StartTime.ToString("dddd dd, MMMM yyyy", CultureInfo.InvariantCulture) + " (" + data.StartTime.ToString(TimeFormat, CultureInfo.InvariantCulture) + "-" + data.EndTime.ToString(TimeFormat, CultureInfo.InvariantCulture) + ")";
        }
        private string GetHeaderStyles(AppointmentData data)
        {
            if (data.Id == default(int))
            {
                return "align-items: center ; color: #919191;";
            }
            else
            {
                CalendarData resData = GetResourceData(data);
                return "background:" + (resData == null ? "#007bff" : resData.CalendarColor) + "; color: #FFFFFF;";
            }
        }
        private async Task SetFocus()
        {
            if (isQuickInfoCreated)
            {
                await Task.Delay(20);
                await SubjectRef.FocusAsync();
            }
        }
        private async Task OnQuickInfoSubjectCreated()
        {
            await Task.Yield();
            await SubjectRef.FocusAsync();
            isQuickInfoCreated = true;
        }
        public void OnToolbarCreated()
        {
            var timer = new Timer(1000);
            timer.Elapsed += new ElapsedEventHandler((object sender, ElapsedEventArgs e) =>
            {
                string key = this.TimezoneData.Key ?? "UTC";
                SystemTime = this.TimeConvertor(key);
                ScheduleRef?.PreventRender();
                InvokeAsync(() => { StateHasChanged(); });
            });
            timer.Enabled = true;
        }
        private CalendarData GetResourceData(AppointmentData data)
        {
            if (data.CalendarId != 0)
            {
                int resourceId = SelectedResource.Where(item => item == data.CalendarId).FirstOrDefault();
                CalendarData resourceData = this.Calendars.Where(item => item.CalendarId == resourceId).FirstOrDefault();
                return resourceData;
            }
            return null;
        }
        private DateTime TimeConvertor(string TimeZoneId)
        {
            return TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById(TimeZoneId));
        }
        private async void OnMoreDetailsClick(MouseEventArgs args, AppointmentData data, bool isEventData)
        {
            await ScheduleRef.CloseQuickInfoPopupAsync();
            if (isEventData == false)
            {
                AppointmentData eventData = new AppointmentData
                {
                    Id = await ScheduleRef.GetMaxEventIdAsync<int>(),
                    Subject = SubjectRef.Value ?? "",
                    StartTime = data.StartTime,
                    EndTime = data.EndTime,
                    Location = data.Location,
                    Description = DescriptionRef.Value ?? "",
                    IsAllDay = data.IsAllDay,
                    CalendarId = CalendarRef.Value,
                    RecurrenceException = data.RecurrenceException,
                    RecurrenceID = data.RecurrenceID,
                    RecurrenceRule = data.RecurrenceRule
                };
                await ScheduleRef.OpenEditorAsync(eventData, CurrentAction.Add);
            }
            else
            {
                AppointmentData eventData = new AppointmentData
                {
                    Id = data.Id,
                    Subject = data.Subject,
                    Location = data.Location,
                    Description = data.Description,
                    StartTime = data.StartTime,
                    EndTime = data.EndTime,
                    IsAllDay = data.IsAllDay,
                    CalendarId = data.CalendarId,
                    RecurrenceException = data.RecurrenceException,
                    RecurrenceID = data.RecurrenceID,
                    RecurrenceRule = data.RecurrenceRule
                };
                if (!string.IsNullOrEmpty(eventData.RecurrenceRule))
                {
                    await ScheduleRef.OpenEditorAsync(eventData, CurrentAction.EditOccurrence);
                }
                else
                {
                    await ScheduleRef.OpenEditorAsync(eventData, CurrentAction.Save);
                }
            }
        }
        private async Task OnDelete(AppointmentData data)
        {
            await ScheduleRef.CloseQuickInfoPopupAsync();
            await ScheduleRef.DeleteEventAsync(data, !string.IsNullOrEmpty(data.RecurrenceRule) ? CurrentAction.DeleteOccurrence : CurrentAction.Delete);
        }

        private async Task OnAdd(MouseEventArgs args, AppointmentData data)
        {
            await ScheduleRef.CloseQuickInfoPopupAsync();

            var cloneData = new AppointmentData
            {
                Id = await ScheduleRef.GetMaxEventIdAsync<int>(),
                Subject = SubjectRef.Value ?? "Add title",
                Description = DescriptionRef.Value ?? "Add notes",
                StartTime = data.StartTime,
                EndTime = data.EndTime,
                CalendarId = CalendarRef.Value,
                Location = data.Location,
                IsAllDay = data.IsAllDay,
                RecurrenceException = data.RecurrenceException,
                RecurrenceID = data.RecurrenceID,
                RecurrenceRule = data.RecurrenceRule
            };
            await ScheduleRef.AddEventAsync(cloneData);
        }
        public void OnWeekNumberChange(Syncfusion.Blazor.DropDowns.ChangeEventArgs<string, WeekNumbers> args)
        {
            switch (args.Value)
            {
                case "Off":
                    this.ShowWeekNumber = false;
                    break;
                case "FirstDay":
                    this.ShowWeekNumber = true;
                    this.WeekRule = CalendarWeekRule.FirstDay;
                    break;
                case "FirstFullWeek":
                    this.ShowWeekNumber = true;
                    this.WeekRule = CalendarWeekRule.FirstFullWeek;
                    break;
                case "FirstFourDayWeek":
                    this.ShowWeekNumber = true;
                    this.WeekRule = CalendarWeekRule.FirstFourDayWeek;
                    break;
            }
        }
        public void OnWeekDaysChange(Syncfusion.Blazor.DropDowns.ChangeEventArgs<int, WeekDays> args)
        {
            this.FirstDayOfWeek = args.Value;
        }
        public void OnWorkDaysChange(Syncfusion.Blazor.DropDowns.MultiSelectChangeEventArgs<int[]> args)
        {
            if (args.Value != null)
            {
                this.WorkDays = args.Value;
            }
        }
        public void OnDayStartHourChange(Syncfusion.Blazor.Calendars.ChangeEventArgs<DateTime?> args)
        {
            if (!string.IsNullOrEmpty(args.Text))
            {
                this.DayStartHour = args.Text;
            }
        }
        public void OnDayEndHourChange(Syncfusion.Blazor.Calendars.ChangeEventArgs<DateTime?> args)
        {
            if (!string.IsNullOrEmpty(args.Text))
            {
                this.DayEndHour = args.Text;
            }
        }
        public void OnWorkStartHourChange(Syncfusion.Blazor.Calendars.ChangeEventArgs<DateTime?> args)
        {
            if (!string.IsNullOrEmpty(args.Text))
            {
                this.WorkStartHour = args.Text;
            }
        }
        public void OnWorkEndHourChange(Syncfusion.Blazor.Calendars.ChangeEventArgs<DateTime?> args)
        {
            if (!string.IsNullOrEmpty(args.Text))
            {
                this.WorkEndHour = args.Text;
            }
        }
        public void OnTimezoneChange(Syncfusion.Blazor.DropDowns.ChangeEventArgs<string, Timezone> args)
        {
            this.TimezoneData = args.ItemData;
            var zones = TimeZoneInfo.GetSystemTimeZones();
            SystemTime = this.TimeConvertor(this.TimezoneData.Key);
        }
        public void OnResourceChange(Syncfusion.Blazor.DropDowns.MultiSelectChangeEventArgs<int[]> args)
        {
            WhereFilter predicate = new WhereFilter();
            if (args.Value != null)
            {
                predicate = new WhereFilter() { Field = "CalendarId", Operator = "equal", value = args.Value.Count() > 0 ? args.Value[0] : 0 }.
                    Or(new WhereFilter() { Field = "CalendarId", Operator = "equal", value = args.Value.Count() > 1 ? args.Value[1] : 0 }).
                    Or(new WhereFilter() { Field = "CalendarId", Operator = "equal", value = args.Value.Count() > 2 ? args.Value[2] : 0 }).
                    Or(new WhereFilter() { Field = "CalendarId", Operator = "equal", value = args.Value.Count() > 3 ? args.Value[3] : 0 });
            }
            else
            {
                predicate = new WhereFilter() { Field = "CalendarId", Operator = "equal", value = 1 };
            }
            this.ResourceQuery = new Query().Where(predicate);
        }
        public void OnGroupChange(Syncfusion.Blazor.Buttons.ChangeEventArgs<bool> args)
        {
            this.EnableGroup = args.Checked;
            this.GroupData = args.Checked ? new string[] { "Calendars" } : null;
        }
        public void OnTimeScaleChange(Syncfusion.Blazor.Buttons.ChangeEventArgs<bool> args)
        {
            this.EnableTimeScale = args.Checked;
        }
        public void OnRowAutoHeightChange(Syncfusion.Blazor.Buttons.ChangeEventArgs<bool> args)
        {
            this.isRowAutoHeight = args.Checked;
        }
        public void OnTooltipChange(Syncfusion.Blazor.DropDowns.ChangeEventArgs<string, Tooltip> args)
        {
            switch (args.Value)
            {
                case "Off":
                    this.TooltipEnable = false;
                    break;
                case "On":
                    this.TooltipEnable = true;
                    break;
            }
        }
        public void OnSlotIntervalChange(Syncfusion.Blazor.DropDowns.ChangeEventArgs<int, SlotData> args)
        {
            this.SlotInterval = args.Value;
        }
        public void OnSlotCountChange(Syncfusion.Blazor.DropDowns.ChangeEventArgs<int, SlotData> args)
        {
            this.SlotCount = args.Value;
        }
        public async Task OnFileUploadChange(UploadChangeEventArgs args)
        {
            foreach (Syncfusion.Blazor.Inputs.UploadFiles file in args.Files)
            {
                StreamReader reader = new StreamReader(file.File.OpenReadStream(long.MaxValue));
                string fileContent = await reader.ReadToEndAsync();
                await ScheduleRef.ImportICalendarAsync(fileContent);
            }
        }

        public async void OnPrintClick()
        {
            await ScheduleRef.PrintAsync();
        }

        public async void OnExportClick(Syncfusion.Blazor.SplitButtons.MenuEventArgs args)
        {
            if (args.Item.Text == "Excel")
            {
                List<AppointmentData> ExportDatas = new List<AppointmentData>();
                List<AppointmentData> EventCollection = await ScheduleRef.GetEventsAsync();
                List<Syncfusion.Blazor.Schedule.Resource> ResourceCollection = ScheduleRef.GetResourceCollections();
                List<CalendarData> ResourceData = ResourceCollection[0].DataSource as List<CalendarData>;
                for (int a = 0, count = ResourceData.Count(); a < count; a++)
                {
                    List<AppointmentData> datas = EventCollection.Where(e => e.CalendarId == ResourceData[a].CalendarId).ToList();
                    foreach (AppointmentData data in datas)
                    {
                        ExportDatas.Add(data);
                    }
                }
                ExportOptions Options = new ExportOptions()
                {
                    ExportType = ExcelFormat.Xlsx,
                    CustomData = ExportDatas,
                    Fields = new string[] { "Id", "Subject", "StartTime", "EndTime", "CalendarId" }
                };
                await ScheduleRef.ExportToExcelAsync(Options);
            }
            else
            {
                await ScheduleRef.ExportToICalendarAsync();
            }
        }
        public async Task OnOpen(BeforeOpenCloseMenuEventArgs<MenuItem> args)
        {
            if (args.ParentItem == null)
            {
                CellData = await ScheduleRef.GetTargetCellAsync((int)args.Left, (int)args.Top);
                await ScheduleRef.CloseQuickInfoPopupAsync();
                if (CellData == null)
                {
                    EventData = await ScheduleRef.GetTargetEventAsync((int)args.Left, (int)args.Top);
                    if (EventData.Id == 0)
                    {
                        args.Cancel = true;
                    }
                    if (EventData.RecurrenceRule != null)
                    {
                        isCell = isEvent = true;
                        isRecurrence = false;
                    }
                    else
                    {
                        isCell = isRecurrence = true;
                        isEvent = false;
                    }
                }
                else
                {
                    isCell = false;
                    isEvent = isRecurrence = true;
                }
            }
        }
        public async Task OnItemSelected(MenuEventArgs<MenuItem> args)
        {
            var SelectedMenuItem = args.Item.Id;
            var ActiveCellsData = await ScheduleRef.GetSelectedCellsAsync();
            if (ActiveCellsData == null)
            {
                ActiveCellsData = CellData;
            }
            switch (SelectedMenuItem)
            {
                case "Today":
                    string key = this.TimezoneData.Key ?? "UTC";
                    SelectedDate = this.TimeConvertor(key);
                    break;
                case "Add":
                    await ScheduleRef.OpenEditorAsync(ActiveCellsData, CurrentAction.Add);
                    break;
                case "AddRecurrence":
                    AppointmentData RecurrenceEventData = null;
                    var resourceDetails = ScheduleRef.GetResourceByIndex(ActiveCellsData.GroupIndex);
                    RecurrenceEventData = new AppointmentData
                    {
                        Id = await ScheduleRef.GetMaxEventIdAsync<int>(),
                        StartTime = ActiveCellsData.StartTime,
                        EndTime = ActiveCellsData.EndTime,
                        CalendarId = resourceDetails.GroupData.CalendarId,
                        RecurrenceRule = "FREQ=DAILY;INTERVAL=1;"
                    };
                    await ScheduleRef.OpenEditorAsync(RecurrenceEventData, CurrentAction.Add);
                    break;
                case "Save":
                    await ScheduleRef.OpenEditorAsync(EventData, CurrentAction.Save);
                    break;
                case "EditOccurrence":
                    await ScheduleRef.OpenEditorAsync(EventData, CurrentAction.EditOccurrence);
                    break;
                case "EditSeries":
                    List<AppointmentData> Events = await ScheduleRef.GetEventsAsync();
                    EventData = (AppointmentData)Events.Where(data => data.Id == EventData.RecurrenceID).FirstOrDefault();
                    await ScheduleRef.OpenEditorAsync(EventData, CurrentAction.EditSeries);
                    break;
                case "Delete":
                    await ScheduleRef.DeleteEventAsync(EventData);
                    break;
                case "DeleteOccurrence":
                    await ScheduleRef.DeleteEventAsync(EventData, CurrentAction.DeleteOccurrence);
                    break;
                case "DeleteSeries":
                    await ScheduleRef.DeleteEventAsync(EventData, CurrentAction.DeleteSeries);
                    break;
            }
        }
    }
}
