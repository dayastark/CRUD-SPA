﻿namespace Schedule.Components.Pages
{
    public partial class Home2
    {

    }
}
