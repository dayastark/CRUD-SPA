﻿using Microsoft.AspNetCore.Components;
using System;

namespace Schedule.Components.Pages
{
    public partial class HomeBackup
    {
        public int CurrentYear { get; set; } = DateTime.Now.Year;

        public int CurrentMonth { get; set; } = DateTime.Now.Month;

        public string Month
        {
            get
            {
                return GetMonthName(this.CurrentMonth);
            }
        }

        public string GetDateFormatted
        {
            get
            {
                return DateTime.Now.ToString("yyyy-MM-dd");
            }
        }

        public string GetDayOfWeek(int day)
        {
            var dateTime = new DateTime(this.CurrentYear, this.CurrentMonth, day);
            return dateTime.DayOfWeek.ToString();
        }



        public int DaysInMonth
        {
            get
            {
                return DateTime.DaysInMonth(this.CurrentYear, this.CurrentMonth);
            }
        }


        private void ChangeMonthControl(ChangeEventArgs changeEventArgs)
        {
            if (changeEventArgs != null && int.TryParse(changeEventArgs.Value.ToString(), out int currentMonth))
            {
                CurrentMonth = currentMonth;
            }

        }

        private void ChangeYearControl(ChangeEventArgs changeEventArgs)
        {
            if (changeEventArgs != null && int.TryParse(changeEventArgs.Value.ToString(), out int currentYear))
            {
                CurrentYear = currentYear;
            }
        }

        private string GetMonthName(int month)
        {
            return GetMonths[month - 1];
        }

        public string[] GetMonths
        {
            get
            {
                return
                [
                    "January", "February",
                    "March", "April", "May", "June", "July",
                    "August", "September",
                    "October", "November", "December"
                ];
            }
        }
    }
}
