﻿using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Schedule.Services
{
    public interface IDatabaseService
    {
        Task<IEnumerable<T>> QueryAsync<T>(string query, object data = null, CommandType commandType =  CommandType.StoredProcedure);
        Task<T> QueryFirstOrDefaultAsync<T>(string query, object data = null, CommandType commandType =  CommandType.StoredProcedure);
        Task<bool> ExecuteAsync<T>(string query, object data = null, CommandType commandType =  CommandType.StoredProcedure);
    }
}
