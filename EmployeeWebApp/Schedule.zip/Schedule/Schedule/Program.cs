using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Schedule.Components;
using Schedule.Services;
using Syncfusion.Blazor;

namespace Schedule
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddRazorComponents()
                .AddInteractiveServerComponents();


            builder.Services.AddScoped<ExceptionHandlingMiddleware>();
            builder.Services.AddScoped<IDatabaseService, DatabaseService>();

            builder.Services.AddSyncfusionBlazor();

            var key = builder.Configuration.GetSection("Syncfusion:key").Value;

            Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense(key);

            var app = builder.Build();

            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();

            app.UseMiddleware<ExceptionHandlingMiddleware>();
            app.UseStaticFiles();
            app.UseAntiforgery();

            app.MapRazorComponents<App>()
                .AddInteractiveServerRenderMode();

            app.Run();
        }
    }
}
