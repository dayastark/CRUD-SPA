﻿namespace Schedule.Components.Pages
{
    public partial class Home
    {
        public class Tooltip
        {
            public string Name { get; set; }
            public string Value { get; set; }
        }
    }
}
