﻿namespace Schedule.Components.Pages
{
    public partial class Home
    {
        public class WeekDays
        {
            public WeekDays()
            {
                    
            }

            public WeekDays(string name, int value)
            {
                Name = name;
                Value = value;
            }

            public string Name { get; set; }
            public int Value { get; set; }
        }
    }
}
