﻿namespace Schedule.Models
{
    public class CalendarData
    {
        public string CalendarName { get; set; }
        public string CalendarColor { get; set; }
        public int CalendarId { get; set; }
    }
}
