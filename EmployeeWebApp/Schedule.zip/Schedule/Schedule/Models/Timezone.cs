﻿namespace Schedule.Components.Pages
{
    public partial class Home
    {
        public class Timezone
        {
            public string Name { get; set; }
            public string Key { get; set; }
            public string Value { get; set; }
        }
    }
}
