﻿using System.Collections.Generic;
using System;

namespace Schedule.Models
{
    public class AppointmentData
    {
        public int Id { get; set; }
        public string Subject { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public string Location { get; set; }
        public string Description { get; set; }
        public bool IsAllDay { get; set; }
        public bool IsReadonly { get; set; }
        public int CalendarId { get; set; }
        public int? RecurrenceID { get; set; }
        public string RecurrenceRule { get; set; }
        public string RecurrenceException { get; set; }
        public AppointmentData() { }

        public AppointmentData(int Id, string Subject, DateTime StartTime, DateTime EndTime, string Location, string Description, bool IsAllDay, bool IsReadonly, int CalendarId, int RecurrenceID, string RecurrenceRule, string RecurrenceException)
        {
            this.Id = Id;
            this.Subject = Subject;
            this.StartTime = StartTime;
            this.EndTime = EndTime;
            this.Location = Location;
            this.Description = Description;
            this.IsAllDay = IsAllDay;
            this.IsReadonly = IsReadonly;
            this.CalendarId = CalendarId;
            this.RecurrenceID = RecurrenceID;
            this.RecurrenceRule = RecurrenceRule;
            this.RecurrenceException = RecurrenceException;
        }
        public List<AppointmentData> GetEvents()
        {
            var EventData = new List<AppointmentData>();
            DateTime YearStart = new DateTime(DateTime.Now.Year, 1, 1);
            DateTime YearEnd = new DateTime(DateTime.Now.Year, 12, 31);
            string[] EventSubjects = new string[] {
                "Bering Sea Gold", "Technology", "Maintenance", "Meeting", "Travelling", "Annual Conference", "Birthday Celebration", "Farewell Celebration",
                "Wedding Anniversary", "Alaska: The Last Frontier", "Deadliest Catch", "Sports Day", "MoonShiners", "Close Encounters", "HighWay Thru Hell",
                "Daily Planet", "Cash Cab", "Basketball Practice", "Rugby Match", "Guitar Class", "Music Lessons", "Doctor checkup", "Brazil - Mexico",
                "Opening ceremony", "Final presentation"
    };
            DateTime CurrentDate = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek + (int)DayOfWeek.Sunday);
            DateTime Start = new DateTime(CurrentDate.Year, CurrentDate.Month, CurrentDate.Day, 10, 0, 0);
            DateTime End = new DateTime(CurrentDate.Year, CurrentDate.Month, CurrentDate.Day, 11, 30, 0);
            EventData.Add(new AppointmentData()
            {
                Id = 1,
                Subject = EventSubjects[new Random().Next(1, 25)],
                StartTime = Start.ToLocalTime(),
                EndTime = End.ToLocalTime(),
                Location = "",
                Description = "Event Scheduled",
                RecurrenceRule = "FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR;INTERVAL=1;COUNT=10;",
                IsAllDay = false,
                IsReadonly = false,
                CalendarId = 1
            });

            for (int a = 0, id = 2; a < 500; a++)
            {
                var random = new Random();
                int Month = random.Next(1, 12);
                int Date = random.Next(1, 28);
                int Hour = random.Next(1, 24);
                int Minutes = random.Next(1, 60);
                DateTime start = new DateTime(YearStart.Year, Month, Date, Hour, Minutes, 0);
                DateTime end = new DateTime(start.Ticks).AddHours(2);
                DateTime StartDate = new DateTime(start.Ticks);
                DateTime EndDate = new DateTime(end.Ticks);
                var eventDatas = new AppointmentData()
                {
                    Id = id,
                    Subject = EventSubjects[random.Next(1, 25)],
                    StartTime = StartDate,
                    EndTime = EndDate,
                    Location = "",
                    Description = "Event Scheduled",
                    IsAllDay = id % 10 == 0,
                    IsReadonly = EndDate < DateTime.Now,
                    CalendarId = (a % 4) + 1
                };
                EventData.Add(eventDatas);
                id++;
            }
            return EventData;
        }
    }
}
