﻿namespace Schedule.Components.Pages
{
    public partial class Home
    {
        public class SlotData : WeekDays 
        {
            public SlotData()
            {

            }

            public SlotData(string name, int value)
            {
                Name = name;
                Value = value;
            }

        }

    }
}
